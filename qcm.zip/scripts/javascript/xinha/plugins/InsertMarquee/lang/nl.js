// I18N constants
// LANG: "nl", ENCODING: UTF-8
// Author: Maarten Molenschot, maarten@nrgmm.nl
{ 
  "Name/ID:": "Naam/ID:",
  "Insert scrolling marquee": "Scrollende tekst invoegen",
  "Insert marquee": "Tekst invoegen",	
  "Direction:": "Richting:",
  "Behavior:": "Gedrag:",
  "Text:": "Tekst:",
  "Background-Color:": "Achtergrondkleur:",
  "Width:": "Breedte:",
  "Height:": "Hoogte:",
  "Speed Control": "Snelheidscontrole",
  "Scroll Amount:": "Snelheid:",
  "Scroll Delay:": "Vertraging:",
  "Cancel": "Annuleren"
};