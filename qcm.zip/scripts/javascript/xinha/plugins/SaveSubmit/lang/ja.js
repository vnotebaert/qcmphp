// I18N constants
// LANG: "ja", ENCODING: UTF-8
{
	"Save": "保存",
	"Saving...": "保存中...",
	"in progress": "処理中",
	"Ready": "レディ"
};