// I18N constants
// LANG: "de", ENCODING: UTF-8
// translated: Raimund Meyer xinha@ray-of-light.org
{
  "Maximize/Minimize Editor": "Editor maximieren/verkleinern"
};
