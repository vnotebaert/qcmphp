<?php
/*
 * Created on 15 mai 2005
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */

// configuration de ma base
$host = "localhost";
$login= "root";
$base = "qcm";
$basepassword="";
global $prefixe;
$prefixe="qcm";
global $langue_par_defaut;
$langue_par_defaut="fr";
?>
