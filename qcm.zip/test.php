<?php
/*
 * Cree le 19 nov. 2005
 *
 * Auteur : David MASSE alias eternel ou Baal Hazgard
 * Email : eternel7@caramail.com
 * Description : fichier de test incluant la generation de la sauvegarde zip de
 * l'environnement.
 * 
 */
//mode debug on=1 / off=0
$debug=0;

?>