// I18N constants
// LANG: "ja", ENCODING: UTF-8
{
  "AsciiMath Formula Input": "AsciiMath 数式入力",
  "Formula Editor": "数式エディタ",
  "Input":"入力",
  "Preview":"表示",
  "Based on ASCIIMathML by ": "Based on ASCIIMathML by ",
  "For more information on AsciiMathML visit this page: ":"AsciiMathの詳細はこのページにあります: ",
  "Attention: Editing the formula in the editor is not possible, please use this dialog!" : "注意: エディタで数式を編集することはできません。必ず、このダイアログを使用してください"
};