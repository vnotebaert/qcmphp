// I18N constants
// LANG: "nl", ENCODING: UTF-8
// Author: Maarten Molenschot, maarten@nrgmm.nl
{
  "Insert GUIDO Music Notation": "GUIDO muziek notatie invoegen",
  "Guido code": "GUIDO-code",
  "Options": "Opties",
  "Format": "Indeling",
  "Image in applet": "Afbeelding in applet",
  "Zoom": "Vergroot/verklein",
  "MIDI File": "MIDI bestand",
  "Image Preview": "Afbeeldingsvoorbeeld",
  "Source Code": "Broncode",
  "Preview": "Voorbeeld",
  "Add MIDI link to allow students to hear the music": "MIDI link invoegen om de muziek te beluisteren",
  "Add GUIDO Code in a textbox on the page": "GUIDO code in een tekstgebied op de pagina invoegen"
};