// I18N for the FullPage plugin
// LANG: "he", ENCODING: UTF-8
// Author: Liron Newman, http://www.eesh.net, <plastish at ultinet dot org>
{
  "Alternate style-sheet:": "גיליון סגנון אחר:",
  "Background color:": "צבע רקע:",
  "Cancel": "ביטול",
  "DOCTYPE:": "DOCTYPE:",
  "Document properties": "מאפייני מסמך",
  "Document title:": "כותרת מסמך:",
  "OK": "אישור",
  "Primary style-sheet:": "גיליון סגנון ראשי:",
  "Text color:": "צבע טקסט:"
};
