// I18N constants
// LANG: "nl", ENCODING: UTF-8
// Author: Maarten Molenschot, maarten@nrgmm.nl
{
  "Insert a Form.": "Formulier invoegen",
  "Insert a text, password or hidden field.": "Tekst, wachtwoord of verborgen veld invoegen",
  "Insert a multi-line text field.": "Een tekstveld met meerdere lijnen invoegen",
  "Insert a select field.": "Een selectielijst invoegen",
  "Insert a check box.": "Een checkbox invoegen",
  "Insert a radio button.": "Een radio knop invoegen",
  "Insert a submit/reset button.": "Een verzend/wis knop invoegen"
};