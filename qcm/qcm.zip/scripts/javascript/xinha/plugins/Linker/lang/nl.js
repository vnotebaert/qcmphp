// I18N constants
// LANG: "nl", ENCODING: UTF-8
// Author: Maarten Molenschot, maarten@nrgmm.nl
{
  "You must select some text before making a new link.": "Selecteer de tekst welke gelinkt moet worden.",
  "Are you sure you wish to remove this link?": "Wilt u deze link werkelijk verwijderen?"
};