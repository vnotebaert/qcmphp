// I18N constants
// LANG: "ja", ENCODING: UTF-8
{
  "Default": "なし",
  "Undefined": "未定義",
  "Choose stylesheet": "スタイルシートの選択"
};