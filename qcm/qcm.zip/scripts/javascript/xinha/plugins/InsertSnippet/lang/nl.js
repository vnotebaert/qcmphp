// I18N constants
// LANG: "nl", ENCODING: UTF-8
// Author: Maarten Molenschot, maarten@nrgmm.nl
{ 
"Insert Snippet": "Snippet invoegen",
"Cancel": "Annuleren",
"Variable":"Variabele",
"Insert as":"Invoegen als",
"Show preview":"Laat voorbeeld zien",
"Hide preview":"Verberg voorbeeld"
};