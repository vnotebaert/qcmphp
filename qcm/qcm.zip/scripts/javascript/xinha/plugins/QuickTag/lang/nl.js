// I18N constants
// LANG: "nl", ENCODING: UTF-8
// Author: Maarten Molenschot, maarten@nrgmm.nl
{ 
  "Quick Tag Editor": "Quick Tag Editor",
  "Enter the TAG you want to insert": "Voer de Tag naam in",
  "You have to select some text": "Selecteer tekst",
  "There are some unclosed quote": "Er zijn niet gesloten quotes",
  "This attribute already exists in the TAG": "Dit attribuut bestaat al in de tag",
  "No CSS class avaiable": "Geen CSS class beschikbaar",
  "OPTIONS": "OPTIES",
  "ATTRIBUTES": "ATTRIBUTEN",
  "TAGs": "TAGs",
  "Colors": "Kleuren",
  "Ok": "Ok",
  "Cancel": "Annuleren"
};