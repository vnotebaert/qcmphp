// LANG: "da", ENCODING: UTF-8
// Author: rene, <rene@laerke.net>

{
  "Bold": "Fed",
  "Italic": "Kursiv",
  "Underline": "Understregning",
  "Strikethrough": "Overstregning ",
  "Subscript": "Sænket skrift",
  "Superscript": "Hævet skrift",
  "Justify Left": "Venstrejuster",
  "Justify Center": "Centrer",
  "Justify Right": "Højrejuster",
  "Justify Full": "Lige margener",
  "Ordered List": "Opstilling med tal",
  "Bulleted List": "Opstilling med punkttegn",
  "Decrease Indent": "Formindsk indrykning",
  "Increase Indent": "Forøg indrykning",
  "Font Color": "Skriftfarve",
  "Background Color": "Baggrundsfarve",
  "Horizontal Rule": "Horisontal linie",
  "Insert Web Link": "Indsæt hyperlink",
  "Insert/Modify Image": "Indsæt billede",
  "Insert Table": "Indsæt tabel",
  "Toggle HTML Source": "HTML visning",
  "Enlarge Editor": "Vis editor i popup",
  "About this editor": "Om htmlarea",
  "Help using editor": "Hjælp",
  "Current style": "Anvendt stil"
}
